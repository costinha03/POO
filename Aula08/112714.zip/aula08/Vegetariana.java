package aula08;

public interface Vegetariana {
    public boolean vegetariano();
}
