package ExameP;

enum SpaceType {
    CARAVAN, CAR, TENT;

    public static SpaceType parse(String string) {
        return null;
    }
}
