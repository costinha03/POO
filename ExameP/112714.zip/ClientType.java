package ExameP;

enum ClientType {
    NORMAL, MEMBER
}
