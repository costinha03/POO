package Aula11;

import java.util.List;

public interface IGradeCalculator {

    double calculateavg(List<Double> grades);
}
